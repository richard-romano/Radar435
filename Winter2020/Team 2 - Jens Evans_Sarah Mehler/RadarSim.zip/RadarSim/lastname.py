#
'''
Add your custom functions here.


'''

def example(variable0, variable1=10, variable2='Text'):
    print('Number/text : {}, number: {}, text: {}'.format(variable0, variable1, variable2))
    x = 4
    return x
