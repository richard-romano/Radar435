'''
IMPORT MODULES
'''
import pyaudio
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pyaudio
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph as pg
import struct
from scipy.fftpack import fft
import scipy.signal as sig
from scipy.signal import chirp, spectrogram, butter, lfilter, freqz
import sys
import time
from scipy.io.wavfile import write

import owens as kdo
# plt.switch_backend('QT4Agg')


'''
RECORD DATA FROM MATRIXXX
'''
# CREATE INSTANCE OF PYAUDIO
p = pyaudio.PyAudio()

chunk = 2048
rate = 44100

# OPEN AND AUDIO STREAM
stream = p.open(rate = rate, format = pyaudio.paInt16, channels = 1, input = True, output = True, frames_per_buffer = chunk)

# START STREAM
stream.start_stream()

# SETUP PARAMETERS/CONSTANTS
x = 0
data = []

num_pulses = 5
PRI = 0.5 #pulse frequency (Hz)
PW = 0.0025 # 2.5ms
PPS = 1/PRI #pulses per second
fs = rate #44100 Hz
BW = 1/PW # bandwidth
fc = 4000 # center freq

# READ AUDIO DATA FROM STREAM
timeout = time.time() + num_pulses*PRI # 2.5 seconds from now
while True:
    data = np.append(data, stream.read(chunk, exception_on_overflow = False))
    if time.time() > timeout:
        break

print('listened...')

# CLOSE STREAM
stream.stop_stream()
stream.close()

# END STREAM
p.terminate

# REFORMAT DATA
data = np.frombuffer(data, dtype=np.int16)


'''
SAVE RECORDED DATA TO .WAV 
'''
#write("Recorded_Pulse.wav", 44100, data)


'''
PLOT RAW RECORDED, ENV, GATED, STACKED, ROLLED DATA
'''
# plot raw recorded data
plt.semilogy(data,label='Raw')
plt.legend()


# envelope data
signal_env = kdo.env(data)

plt.semilogy(signal_env,label='Enveloped')
plt.legend()

print("length of signal_env array " + str(len(signal_env)))


# GET RID OF LARGE INITIAL SPIKE
signal_env = signal_env[500:]

plt.semilogy(signal_env, label='good start')
plt.legend()
plt.title('Raw, enveloped and good start recording')
plt.ylabel('amplitude')
plt.xlabel('samples')
plt.show()


#RESHAPE DATA (GATING)
nsamps = len(signal_env)
if nsamps%num_pulses != 0:
    signal_env = signal_env[nsamps%num_pulses:]     

signal_env = signal_env.reshape(num_pulses,int(nsamps/num_pulses))


plt.title('stack pulses')
for idx in range(0, num_pulses):
    plt.subplot(num_pulses+1,1,idx+1)
    plt.semilogy(signal_roll[idx,::])

plt.ylabel('amplitude')
plt.xlabel('samples')    
plt.show()

'''
ROLL SIGNALS
'''
signal_roll = signal_stack
for idx in range(0, num_pulses):
    peak_signal = np.amax(signal_stack[idx,:])
    maxInd_signal = np.where(signal_stack[idx,:] == np.amax(signal_stack[idx,:]))
    signal_roll[idx,:] = np.roll(signal_stack[idx,:], -(maxInd_signal[0]-250))

print("signal rolled to start")

plt.title('rolled pulses')
for idx in range(0, num_pulses):
    plt.subplot(num_pulses+1,1,idx+1)
    plt.semilogy(signal_roll[idx,::])

plt.show()

# SUM PULSES TOGETHER
signal_summed = signal_roll.sum(axis=0)

NF = np.empty(len(signal_summed))
NF.fill(np.average(signal_summed))

plt.semilogy(signal_summed)

print("pulses stacked (summed)")

plt.title('sum of pulses')
plt.ylabel('amplitude')
plt.xlabel('samples')
plt.semilogy(NF[0:(len(signal_summed))], label='threshold')
plt.legend()
plt.show()



'''
CROSS CORRELATE
ENVELOPED SIGNAL
WITH ENVELOPED PULSE TRAIN
'''
# create instance of kernel from pulse
dt = (1/4000)/20
t_vector = np.arange(0, PRI, dt)
PWidx = np.int(PW/dt)

amplitude = np.iinfo(np.int16).max
A = amplitude

kernel = A * np.sin(2* np.pi * np.int(4000) * t_vector)
kernel = kernel[:PWidx]
print("kernel pulse made")

plt.title('kernel signal')
plt.xlabel('amplitude')
plt.ylabel('t (sec)')
plt.plot(t_vector[:PWidx], kernel[:PWidx])
plt.show()


# envelope kernel
kernel_env = kdo.env(kernel[:PWidx])


# correlate
xcorr_sig = sig.correlate(signal_summed, kernel_env,'same')

plt.title('x-correlated signal')
plt.xlabel('amplitude')
#plt.ylabel('t (sec)')
plt.semilogy(xcorr_sig)
plt.show()



'''
FIND MAX PEAKS IN RANGES OF INTEREST
'''

peaks = kdo.peak_detection(xcorr_sig)
print("peaks found")

nsamps = len(xcorr_sig)
x = np.linspace(0,R_unamb, nsamps)
dx=R_unamb/nsamps

plt.plot(x/1e3,xcorr_sig,label='xcorr_env')
#plt.axhline(y=10*np.log10(trigger/1e-3),xmin=0, xmax=len(xcorr_sig),linewidth=1,color='r',linestyle='dotted')
plt.plot(x/1e3,NF[:len(x)],label='noise floor',color='green', linestyle='--', dashes=(5,3))
plt.plot(peaks*dx/1e3,xcorr_sig[peaks],'x',label='peaks')
plt.title('Peak Detection')
plt.legend()
plt.ylabel('amplitude')
plt.xlabel('distance (km)')
plt.show()


'''
DISTANCE OF INTEREST
'''
peak_signal = np.amax(xcorr_sig[1750:2250])
maxInd_signal = np.where(xcorr_sig[1750:2250] == np.amax(xcorr_sig[1750:2250]))

print(maxInd_signal[0]+1750)
distance = (vp/rate)*(maxInd_signal[0]+1750)

print("Calculated Distance of Wall from Matrix = " + str(distance))

Actual = int(input("What is the measured distance to the target? "))


print("Delta distance between measured and calculated = " + int(Actual-distance))

