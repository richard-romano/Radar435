import numpy as np
import scipy.signal as sig
import matplotlib
import matplotlib.pyplot as plt
from scipy.signal import butter, lfilter, freqz

def env(signal):
    signal = sig.hilbert(signal)
    envelope = abs(signal)
    return envelope

def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a

def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    y = lfilter(b, a, data)
    return y

def peak_detection(xcorr_env):
    peaks = []
    for idx in range(0,len(xcorr_env)-1): # IN RANGE OF ~10METERS (TARGET DSITANCE)
        if xcorr_env[idx] > xcorr_env[idx-1] and xcorr_env[idx] > xcorr_env[idx+1] and xcorr_env[idx] > (np.average(xcorr_env)):
            peaks.append(idx)
    peaks = np.array(peaks)
    return peaks
    

    
    
    
    
    
    
    
    
    