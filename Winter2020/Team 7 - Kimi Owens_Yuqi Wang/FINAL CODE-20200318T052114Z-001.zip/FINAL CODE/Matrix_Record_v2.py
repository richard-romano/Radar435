'''
IMPORT MODULES
'''
import pyaudio
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pyaudio
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph as pg
import struct
from scipy.fftpack import fft, fftfreq, ifft
import scipy.signal as sig
from scipy.signal import chirp, spectrogram, butter, lfilter, freqz
import sys
import time
from scipy.io.wavfile import write

import owens as kdo


'''
RECORD DATA FROM MATRIXXX
'''
# CREATE INSTANCE OF PYAUDIO
p = pyaudio.PyAudio()

chunk = 2048
rate = 44100

# OPEN AND AUDIO STREAM
stream = p.open(rate = rate, format = pyaudio.paInt16, channels = 1, input = True, output = True, frames_per_buffer = chunk)

# START STREAM
stream.start_stream()

# SETUP PARAMETERS/CONSTANTS
x = 0
data = []

num_pulses = 12
PRI = 0.2 #pulse frequency (Hz)
PW = 0.0025 # 2.5ms
PPS = 1/PRI #pulses per second
fs = rate #44100 Hz
BW = 1/PW # bandwidth
fc = 4000 # center freq
vp = 343 # speed of sound
R_unamb = PRI *vp/2

# READ AUDIO DATA FROM STREAM
timeout = time.time() + num_pulses*PRI 
while True:
    data = np.append(data, stream.read(chunk, exception_on_overflow = False))
    if time.time() > timeout:
        break

print('listened...')

# CLOSE STREAM
stream.stop_stream()
stream.close()

# END STREAM
p.terminate

# REFORMAT DATA
data = np.frombuffer(data, dtype=np.int16)


'''
GET RID OF LARGE INITIAL SPIKE
'''
data = data[500:]

plt.figure(1)
plt.plot(data, label='raw data')
plt.legend()
plt.title('Raw Signal')
plt.ylabel('amplitude')
plt.xlabel('sample')
#plt.show()


'''
FFT DATA
'''
# SET UP PARAMETERS
N = len(data) # number of samples
Ts = 1/rate # sampling interval
Fs = rate # sampling frequency
Fn = Fs/2 # Nyquist frequency
# T = np.linspace(0,(PRI*num_pulses), Ts)
freq = fftfreq(N)
mask = freq > 0

raw_fft = 2 * np.abs(fft(data)/2)

# plt.figure(2)
# plt.semilogy(freq[mask], raw_fft[mask], label='raw fft')
# plt.legend()
# plt.show()

'''
FILTER DATA
'''
lowcut = 3500
highcut = 4500
signal_filt = kdo.butter_bandpass_filter(data, lowcut, highcut, fs, order=5)

#signal_filt_fft = 2 * np.abs(fft(signal_filt)/2)

# plt.figure(3)
# plt.semilogy(freq[mask], signal_filt_fft[mask], label='filt fft1')
# plt.legend()

plt.figure(2)
plt.plot(signal_filt,label='filt signal')
plt.legend()
plt.title('Filtered Signal')
plt.ylabel('amplitude')
plt.xlabel('sample')
plt.show()


'''
RESHAPE DATA (GATE/STACK)
'''
nsamps = len(signal_filt)
if nsamps%num_pulses != 0:
    signal_filt = signal_filt[nsamps%num_pulses:]     

signal_stack = signal_filt.reshape(num_pulses,int(nsamps/num_pulses))

print("signal stacked")

# for idx in range(0, num_pulses):
#     plt.subplot(num_pulses+1,1,idx+1)
#     plt.semilogy(signal_stack[idx,::])
# plt.title('stack pulses')
# plt.ylabel('amplitude')
# plt.xlabel('samples')    
# plt.show()

'''
ROLL RECORDED SIGNAL TO START
'''
# find max amplitude of each pulse and roll to start
signal_roll = signal_stack
for idx in range(0, num_pulses):
    peak_signal = np.amax(signal_stack[idx,:])
    maxInd_signal = np.where(signal_stack[idx,:] == np.amax(signal_stack[idx,:]))
    signal_roll[idx,:] = np.roll(signal_stack[idx,:], -(maxInd_signal[0]-250))

print("signal rolled to start")

# plt.title('rolled pulses')
# for idx in range(0, num_pulses):
#     plt.subplot(num_pulses+1,1,idx+1)
#     plt.semilogy(signal_roll[idx,::])
# 
# plt.show()


'''
SUM PULSES TOGETHER
'''
signal_summed = signal_roll.sum(axis=0)
plt.plot(signal_summed)

print("pulses summed")

plt.title('Sum of Pulses')
plt.ylabel('amplitude')
plt.xlabel('samples')
plt.show()

'''
CROSS CORRELATE
FILTERED SIGNAL
WITH FM CHIRP
'''
# SET UP PARAMETERS
dt = (1/4000)/20
t_vector = np.arange(0, PRI, dt)
PWidx = np.int(PW/dt)
kernel = chirp(t_vector, f0=1000, f1=7000, t1=0.0025, method='linear')
kernel = kernel[:PWidx]

print("kernel pulse made")

plt.figure(1)
plt.plot(t_vector[:PWidx], kernel)
plt.title('Kernel FM Chirp')
plt.ylabel('amplitude')
plt.xlabel('t (sec)')


xcorr_kern = sig.correlate(kernel, kernel,'same')
plt.figure(2)
plt.plot(xcorr_kern)
plt.title('Kernel vs Kernel X-Corr')
plt.ylabel('amplitude')
plt.xlabel('t (sec)')
plt.show()


# correlate
xcorr_sig = sig.correlate(signal_summed, kernel,'same')

plt.figure(1)
plt.title('x-correlated signal')
plt.ylabel('amplitude')
plt.xlabel('sample')
plt.plot(xcorr_sig,label='x-corr signal')
#plt.show()


# ENVELOPE XCORR
xcorr_env = kdo.env(xcorr_sig)

'''
FIND AVERAGE NOISE FLOOR OF ENVELOPED X-CORR
'''
NF = np.empty(len(xcorr_env))
NF.fill(np.average(xcorr_env))

plt.figure(2)
plt.title('x-correlated signal')
plt.ylabel('amplitude')
plt.xlabel('sample')
plt.plot(xcorr_env, label='x-corr signal enveloped')
plt.plot(NF,label='Noise Floor')
plt.show()

'''
FIND MAX PEAKS IN RANGES OF INTEREST
'''

peaks = kdo.peak_detection(xcorr_env)
print("peaks found")

nsamps = len(xcorr_env)
x = np.linspace(0,R_unamb, nsamps)
dx=R_unamb/nsamps

plt.plot(x/1e3,xcorr_env,label='xcorr_env')
#plt.axhline(y=10*np.log10(trigger/1e-3),xmin=0, xmax=len(xcorr_sig),linewidth=1,color='r',linestyle='dotted')
plt.plot(x/1e3,NF[:len(x)],label='noise floor',color='green', linestyle='--', dashes=(5,3))
plt.plot(peaks*dx/1e3,xcorr_env[peaks],'x',label='peaks')
plt.title('Peak Detection')
plt.legend()
plt.ylabel('amplitude')
plt.xlabel('distance (km)')
plt.show()


'''
DISTANCE OF INTEREST
'''
peak_signal = np.amax(xcorr_env[1750:2250])
maxInd_signal = np.where(xcorr_env[1750:2250] == np.amax(xcorr_env[1750:2250]))

print(maxInd_signal[0]+1750)
distance = (vp/rate)*(maxInd_signal[0]+1750)

print("Calculated Distance of Wall from Matrix = " + str(distance))

Actual = int(input("What is the measured distance to the target? "))


print("Delta distance between measured and calculated = " + int(Actual-distance))



